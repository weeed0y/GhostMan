# Copyright (C) 2020 by TechnoAyanOfficial@Github, < https://github.com/TechnoAyanOfficial >.
#
# This file is part of < https://github.com/TechnoAyanOfficial/TechnoAyanBOT > project,
# and is released under the "GNU v3.0 License Agreement".
# Please see < https://github.com/TechnoAyanOfficial/TechnoAyanBOT/blob/Exclusive/LICENSE >
#
# All rights reserved.

import os

STICKER_PACK_NAME = os.environ.get("STICKER_PACK_NAME", "Creepy Stickers")

ANIMATED_STICKER_PNAME = os.environ.get("ANIMATED_STICKER_PNAME", "Creepy Animated Stickers")

AUTONAME = os.environ.get("AUTONAME", None)

CHANNEL_LINK = os.environ.get("CHANNEL_LINK", "https://t.me/TechnoAyanBoT/80")

ALIVE_NAME = os.environ.get("ALIVE_NAME", None)